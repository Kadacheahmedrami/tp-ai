import type { TimetableSolution } from "@/lib/types"
import { getCourseColor } from "@/lib/utils"

interface TimetableProps {
  solution: TimetableSolution
}

// Define hours for each slot
const HOURS = ["08:30 AM", "10:00 AM", "11:30 AM", "01:00 PM", "02:30 PM"]
const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"]

export function Timetable({ solution }: TimetableProps) {
  return (
    <div className="overflow-x-auto">
      <div className="min-w-[800px]">
        <div className="grid grid-cols-[180px_repeat(5,1fr)] gap-2">
          {/* Empty top-left cell */}
          <div className="h-14 flex items-center justify-center font-bold"></div>

          {/* Days header */}
          {DAYS.map((day) => (
            <div key={day} className="h-14 flex items-center justify-center font-bold bg-gray-800 rounded-md">
              {day}
            </div>
          ))}

          {/* Time slots and courses */}
          {HOURS.map((hour, slotIndex) => (
            <>
              {/* Hour label */}
              <div key={hour} className="h-14 flex items-center justify-center font-medium bg-gray-800 rounded-md">
                {hour}
              </div>

              {/* Course cells for this time slot */}
              {DAYS.map((day) => {
                const course = Object.entries(solution).find(
                  ([_, [courseDay, courseSlot]]) => courseDay === day && courseSlot === slotIndex,
                )?.[0]

                if (!course) {
                  return (
                    <div
                      key={`${day}-${slotIndex}`}
                      className="h-14 flex items-center justify-center bg-gray-800/30 rounded-md"
                    ></div>
                  )
                }

                const courseBase = course.split("_")[0]
                const courseType = course.split("_")[1]
                const bgColor = getCourseColor(courseBase)

                return (
                  <div
                    key={`${day}-${slotIndex}`}
                    className={`h-14 flex flex-col items-center justify-center rounded-md ${bgColor} text-gray-900 font-medium`}
                  >
                    <div>{courseBase}</div>
                    <div className="text-xs opacity-80">{courseType}</div>
                  </div>
                )
              })}
            </>
          ))}
        </div>
      </div>
    </div>
  )
}
